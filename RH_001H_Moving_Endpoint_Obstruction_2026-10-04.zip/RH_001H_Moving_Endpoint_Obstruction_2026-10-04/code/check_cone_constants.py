#!/usr/bin/env python3
"""Fresh exact checks of the reviewed cone's finite inequalities.
These checks are not a machine proof of the contour, ODE, or convergence arguments.
"""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import hashlib, json, datetime

if __debug__ is False:
    raise RuntimeError('Run without -O: assertions are part of the checks')

checks={}
def test(name,condition):
    if not condition: raise AssertionError(name)
    checks[name]=True

a=F(51,2); z=F(85,2)
loss=F(10,27)*F(4,3)/a*(a/(a-2))**4
exp_poly=sum((F(17,2)**k/F(factorial(k)) for k in range(7)),F(0))
test('loss_value',loss==F(393040,14639043))
test('loss_below_one_over_36',loss<F(1,36))
test('e_bound',F(49,18)<F(11,4))
test('pi_bound',F(52,15)<F(32,9))
test('Bessel_coefficient',F(4,11)-F(1,36)==F(133,396)>F(1,3))
test('quarter_coefficient_squared',F(1,9)*2/F(32,9)==F(1,16))
test('turning_point',(F(5,4)**2-1)*34**2>F(1,4))
test('sinh_positive',z>2*F(52,15))
test('kernel_polynomial',1-6/z+6/z**2>F(1,2))
test('remainder_prefactor',1+6/z+12/z**2<F(3,2))
test('geometric_ratio',F(8,2**6)<F(1,2))
test('main_dominance',exp_poly==F(58017253,46080)>768)
result={'status':'PASS_EXACT_FINITE_CONSTANTS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'checks':checks,'count':len(checks),'loss':str(loss),'exp_polynomial':str(exp_poly),
        'scope':'Finite constants only; reviewed analysis controls the unbounded cone.'}
print(json.dumps(result,indent=2))
