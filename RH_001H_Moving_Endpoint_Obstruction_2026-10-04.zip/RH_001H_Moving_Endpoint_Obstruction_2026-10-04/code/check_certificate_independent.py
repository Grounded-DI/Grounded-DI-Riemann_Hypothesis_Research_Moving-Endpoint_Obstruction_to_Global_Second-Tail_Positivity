#!/usr/bin/env python3
"""Separate finite-sign reconstruction.

Does NOT import the producing program or reuse its logarithm implementation.
Checks 16th-root witnesses with exact integer powers, counts divisors directly,
counts prime factors by an independent sieve, and bounds logs by exact rational
composite Simpson integration of 1/u with the explicit fourth-derivative error.
This checker establishes a second enclosure of D_224 and B_224.
"""
import argparse, json, hashlib, datetime
from pathlib import Path
from fractions import Fraction

X=224
BITS=60
Q=1<<BITS
PANELS=64

def ceildiv(a,b):return -((-a)//b)
def quantize(f,up):
    n=f.numerator*Q;d=f.denominator
    return ceildiv(n,d) if up else n//d

def log_by_simpson(y):
    assert Fraction(1)<=y<=Fraction(2)
    h=(y-1)/PANELS
    total=1+1/y
    for j in range(1,PANELS):
        total+=(4 if j%2 else 2)/(1+j*h)
    approx=h*total/3
    # Composite Simpson: |error| <= (b-a) h^4 sup|f''''|/180,
    # f(u)=1/u, sup|f''''|=24 on every subinterval of [1,2].
    err=(y-1)*h**4*Fraction(2,15)
    return approx-err,approx+err

def log_ratio(n):
    k=0
    while (1<<(k+1))*n<=X:k+=1
    y=Fraction(X,n*(1<<k))
    a,b=log_by_simpson(y);c,d=log_by_simpson(Fraction(2))
    return max(Fraction(0),a+k*c),b+k*d

def main():
    parser=argparse.ArgumentParser();parser.add_argument('certificate');args=parser.parse_args()
    data=json.loads(Path(args.certificate).read_text())
    assert data['X']==X and data['bits']==100
    qr=1<<100
    assert data['Q']==str(qr)
    rows=data['rows'];assert [r['n'] for r in rows]==list(range(1,X))
    # Count multiplicities by a sieve over all prime powers.
    prime=[True]*X;prime[0]=prime[1]=False;omega=[0]*X
    for p in range(2,X):
        if prime[p]:
            for m in range(p*p,X,p):prime[m]=False
            q=p
            while q<X:
                for m in range(q,X,q):omega[m]+=1
                q*=p
    dlo=dhi=blo=bhi=0
    for row in rows:
        n=row['n'];d=sum(1 for k in range(1,n+1) if n%k==0)
        o=omega[n]
        assert row['d']==d and row['Omega']==o
        a=int(row['root_floor_scaled']);b=int(row['root_upper_scaled'])
        assert a**16<=n*qr**16<=b**16
        assert a**16<=n*qr**16<(a+1)**16 and b-a in [0,1]
        l,u=log_ratio(n)
        wl=quantize(Fraction(d*a,qr*n)*l,False)
        wu=quantize(Fraction(d*b,qr*n)*u,True)
        if o%2:dlo-=wu;dhi-=wl
        else:dlo+=wl;dhi+=wu
        blo+=(o*o*wl)//2;bhi+=ceildiv(o*o*wu,2)
    assert dhi*100 < -3*Q
    assert bhi < 156*Q
    # A different, wider enclosure contains the producing exact enclosure.
    assert dlo*qr <= int(data['D']['lower_scaled'])*Q
    assert int(data['D']['upper_scaled'])*Q <= dhi*qr
    assert blo*qr <= int(data['B']['lower_scaled'])*Q
    assert int(data['B']['upper_scaled'])*Q <= bhi*qr
    result={'status':'PASS_INDEPENDENT_EXACT_RECONSTRUCTION',
      'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'input_sha256':hashlib.sha256(Path(args.certificate).read_bytes()).hexdigest(),
      'X':X,'terms':len(rows),'prime_phases':sum(prime),'Q':str(Q),
      'D_lower_scaled':str(dlo),'D_upper_scaled':str(dhi),
      'B_lower_scaled':str(blo),'B_upper_scaled':str(bhi),
      'D_display_only':[float(Fraction(dlo,Q)),float(Fraction(dhi,Q))],
      'B_display_only':[float(Fraction(blo,Q)),float(Fraction(bhi,Q))],
      'D_below_minus_3_over_100':True,'B_below_156':True,
      'algorithm':'Exact rational Simpson bounds, direct divisor counting, prime-power sieve, exact root-witness powers',
      'scope':'Finite sign/sensitivity certificate only, not the universal analytic theorem'}
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
