#!/usr/bin/env python3
"""Replay exact finite certificates into a NEW directory. Standard library only.
This is not a machine proof of the analytical existence theorem.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,platform,subprocess,sys,time

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def strip_runtime(data):
    data=dict(data)
    for key in ['utc','python']:data.pop(key,None)
    return data

def main():
    if not __debug__ or os.environ.get('PYTHONOPTIMIZE'):
        raise RuntimeError('Run ordinary Python without -O or PYTHONOPTIMIZE')
    pa=argparse.ArgumentParser();pa.add_argument('new_output_directory');args=pa.parse_args()
    root=Path(__file__).resolve().parents[1]
    dest=Path(args.new_output_directory).resolve();dest.mkdir(parents=True,exist_ok=False)
    scripts=['certify_divisor_polynomial.py','check_certificate_independent.py','check_cone_constants.py','check_phase_algebra.py']
    record={'utc_started':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'python':platform.python_version(),'sources':{s:sha(root/'code'/s) for s in scripts},'runs':[]}
    (dest/'PRE_RUN.json').write_text(json.dumps(record,indent=2)+'\n')
    def run(label,script,extra):
        cmd=[sys.executable,str(root/'code'/script),*map(str,extra)]
        start=time.monotonic();p=subprocess.run(cmd,text=True,capture_output=True)
        (dest/(label+'.stdout.json')).write_text(p.stdout)
        (dest/(label+'.stderr.txt')).write_text(p.stderr)
        record['runs'].append({'label':label,'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start})
        (dest/'RUN_RECORD.json').write_text(json.dumps(record,indent=2)+'\n')
        if p.returncode:raise RuntimeError(f'{label} failed; see preserved output')
        return json.loads(p.stdout)
    cert=dest/'divisor_certificate.json'
    run('producer','certify_divisor_polynomial.py',['--output',cert])
    original=json.loads((root/'results'/'divisor_certificate.json').read_text())
    fresh=json.loads(cert.read_text())
    if strip_runtime(original)!=strip_runtime(fresh):raise AssertionError('Regenerated certificate differs mathematically')
    check=run('separate_checker','check_certificate_independent.py',[cert])
    run('cone_constants','check_cone_constants.py',[])
    run('phase_algebra','check_phase_algebra.py',[])
    record.update({'utc_finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'status':'PASS_FINITE_CERTIFICATE_REPLAY','mathematical_certificate_matches':True,
      'root_witnesses_and_independent_log_sign_check':check['status'],
      'scope':'Exact finite certificates only. No formal analytic proof and no Arb V2 evaluation.'})
    (dest/'RUN_RECORD.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))
if __name__=='__main__':main()
