#!/usr/bin/env python3
"""Exact integer/rational certificate: no floating-point or special-function trust.

D_X = sum_{n<X} d(n) (-1)^Omega(n) n^(-15/16) log(X/n).
B_X = (1/2)sum_{n<X} d(n) Omega(n)^2 n^(-15/16) log(X/n).
At X=224, prove D_X < -3/100 and B_X < 156.

Roots: integer bisection, verified by 16th powers.
Logs: argument reduction and the positive atanh series with explicit remainder.
Every arithmetic enclosure is outward-rounded to an integer multiple of 2^-100.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse, hashlib, json, platform, datetime

BITS=100
Q=1<<BITS
NTERMS=36
X=224

def ceildiv(a:int,b:int)->int:
    return -((-a)//b)

def floor_q(a:F)->int:
    return (a.numerator*Q)//a.denominator

def ceil_q(a:F)->int:
    return ceildiv(a.numerator*Q,a.denominator)

def root16_floor(n:int)->int:
    target=n << (16*BITS)
    lo,hi=0,2*Q
    while hi-lo>1:
        m=(lo+hi)//2
        if m**16<=target:lo=m
        else:hi=m
    assert lo**16<=target<(lo+1)**16
    return lo

def log_small_interval(y:F):
    assert 1<=y<=2
    u=(y-1)/(y+1)
    s=F(0);power=u;u2=u*u
    for k in range(NTERMS):
        s+=2*power/(2*k+1)
        power*=u2
    remainder=2*power/((2*NTERMS+1)*(1-u2))
    return s,s+remainder

def log_ratio_interval(n:int):
    y=F(X,n);k=0
    while y>=2:y/=2;k+=1
    l,u=log_small_interval(y)
    l2,u2=log_small_interval(F(2))
    return floor_q(l+k*l2),ceil_q(u+k*u2),k,y

def factor_data(n:int):
    v=n;p=2;f=[]
    while p*p<=v:
        e=0
        while v%p==0:v//=p;e+=1
        if e:f.append([p,e])
        p+=1
    if v>1:f.append([v,1])
    d=1;o=0
    for p,e in f:d*=e+1;o+=e
    return f,d,o

def outward_decimal(k:int,places:int,upper:bool)->str:
    scale=10**places
    v=ceildiv(k*scale,Q) if upper else (k*scale)//Q
    sign='-' if v<0 else '';v=abs(v)
    return f'{sign}{v//scale}.{v%scale:0{places}d}'

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--output',required=True);args=pa.parse_args()
    out=Path(args.output)
    if out.exists():raise FileExistsError('Refusing to overwrite an existing certificate')
    dlo=dhi=blo=bhi=0;rows=[]
    for n in range(1,X):
        factors,d,omega=factor_data(n)
        rootlo=root16_floor(n)
        rootup=rootlo if rootlo**16==(n << (16*BITS)) else rootlo+1
        loglo,logup,k,y=log_ratio_interval(n)
        assert loglo>=0
        # n^-15/16 = n^(1/16)/n; all factors here are nonnegative.
        wlo=(d*rootlo*loglo)//(Q*n)
        wup=ceildiv(d*rootup*logup,Q*n)
        if omega%2:dlo-=wup;dhi-=wlo
        else:dlo+=wlo;dhi+=wup
        blo+=(omega*omega*wlo)//2
        bhi+=ceildiv(omega*omega*wup,2)
        rows.append({'n':n,'factors':factors,'d':d,'Omega':omega,
          'root_floor_scaled':str(rootlo),'root_upper_scaled':str(rootup),
          'log_reduction_k':k,'log_reduction_y':str(y),
          'log_lower_scaled':str(loglo),'log_upper_scaled':str(logup),
          'weight_lower_scaled':str(wlo),'weight_upper_scaled':str(wup)})
    assert dhi*100 < -3*Q
    assert bhi < 156*Q
    # For prime-phase error <=1/100, P <= D+B/10000 < -9/625.
    assert dhi*10000+bhi < -(9*Q*10000)//625
    result={'status':'PASS_EXACT_ARITHMETIC','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'python':platform.python_version(),'X':X,'sigma':'15/16','bits':BITS,'Q':str(Q),'log_terms':NTERMS,
      'D':{'lower_scaled':str(dlo),'upper_scaled':str(dhi),
           'outward_decimal':[outward_decimal(dlo,24,False),outward_decimal(dhi,24,True)],'proves':'D < -3/100'},
      'B':{'lower_scaled':str(blo),'upper_scaled':str(bhi),
           'outward_decimal':[outward_decimal(blo,24,False),outward_decimal(bhi,24,True)],'proves':'B < 156'},
      'phase_neighborhood':'distance(t log q, pi mod 2pi) <= 1/100 for every prime q <224',
      'phase_conclusion':'P_(15/16)(t,224) < -9/625',
      'scope':'Finite divisor polynomial and phase-sensitivity constant ONLY; not a finite-height V2 evaluation.',
      'rows':rows}
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
if __name__=='__main__':main()
