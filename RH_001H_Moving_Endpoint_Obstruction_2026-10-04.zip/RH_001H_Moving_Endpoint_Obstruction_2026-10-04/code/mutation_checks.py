#!/usr/bin/env python3
"""Selected adversarial certificate mutations, not a mathematical proof."""
from pathlib import Path
import argparse,copy,hashlib,json,subprocess,sys,datetime

def main():
    if not __debug__:raise RuntimeError('Run without -O')
    pa=argparse.ArgumentParser();pa.add_argument('new_output_directory');a=pa.parse_args()
    root=Path(__file__).resolve().parents[1];out=Path(a.new_output_directory).resolve()
    out.mkdir(parents=True,exist_ok=False)
    original=json.loads((root/'results/divisor_certificate.json').read_text())
    checker=root/'code/check_certificate_independent.py'
    changes=[('bad_root',lambda d:d['rows'][1].update(root_floor_scaled='0')),
             ('bad_divisor_count',lambda d:d['rows'][1].update(d=3)),
             ('missing_term',lambda d:d['rows'].pop()),
             ('false_nonnegative_upper',lambda d:d['D'].update(upper_scaled='0'))]
    results=[]
    for name,change in changes:
        d=copy.deepcopy(original);change(d)
        path=out/(name+'.json');path.write_text(json.dumps(d,indent=2)+'\n')
        p=subprocess.run([sys.executable,str(checker),str(path)],capture_output=True,text=True)
        (out/(name+'.stdout.txt')).write_text(p.stdout);(out/(name+'.stderr.txt')).write_text(p.stderr)
        passed=p.returncode!=0 and 'AssertionError' in p.stderr
        results.append({'name':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'exit_code':p.returncode,'rejected_by_assertion':passed})
        if not passed:raise AssertionError(name)
    record={'status':'PASS_SELECTED_MUTATION_REJECTIONS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       'checker_sha256':hashlib.sha256(checker.read_bytes()).hexdigest(),'mutations':results,
       'scope':'Four selected corruptions of a finite certificate. No claim of universal tamper detection or analytic verification.'}
    (out/'MUTATION_RECORD.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))
if __name__=='__main__':main()
