#!/usr/bin/env python3
"""Exact finite algebra audit for all n<224 and their divisors.
The unbounded-time recurrence and cosine inequality are analytic, not tested here.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,datetime
if not __debug__:raise RuntimeError('Do not run with -O')
X=224

def fac(n):
    out={};p=2
    while p*p<=n:
        while n%p==0:
            out[p]=out.get(p,0)+1;n//=p
        p+=1
    if n>1:out[n]=out.get(n,0)+1
    return out

count=0
for n in range(1,X):
    a=fac(n);on=sum(a.values())
    for d in range(1,n+1):
        if n%d:continue
        b=fac(d);od=sum(b.values())
        coeff=[a[q]-2*b.get(q,0) for q in a]
        assert sum(coeff)==on-2*od
        assert sum(abs(c) for c in coeff)<=on
        assert sum(coeff)%2==on%2
        count+=1
assert F(-3,100)+F(156,10000)==F(-9,625)
assert F(-9,625)+F(1,250)==F(-13,1250)<F(-1,100)
assert F(5,4)/F(1,224)==280
print(json.dumps({'status':'PASS_EXACT_PHASE_ALGEBRA','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'integer_terms':X-1,'divisor_pairs_checked':count,'phase_radius':'1/100',
 'polynomial_upper':'-9/625','post_error_upper':'-13/1250','final_coarse_upper':'-1/100',
 'cone_to_negative_argument_ratio':'280','scope':'Finite algebra only'},indent=2))
