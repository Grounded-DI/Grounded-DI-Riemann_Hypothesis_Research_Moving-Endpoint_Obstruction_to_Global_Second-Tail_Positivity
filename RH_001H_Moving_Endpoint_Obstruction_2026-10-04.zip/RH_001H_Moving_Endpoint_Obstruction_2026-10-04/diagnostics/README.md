# Non-certifying reconnaissance — not proof premises

Four concurrent mpmath/Simpson jobs at t=35,40,50,80 used 240 radial grid points and heuristic product/tail truncation. No negative sample was observed on those selected grids. There is no validated error bound, no continuous-coverage certificate, and no implication about other heights.

The separate Liouville/divisor reconnaissance suggested X=224. The rigorous successor instead uses two exact finite-sign computations and a written phase-uniform asymptotic argument. The reconnaissance numbers, including positive observations, are preserved but not imported as proof premises.

Historical diagnostic scripts can require numpy/scipy/mpmath. They are not invoked by the standard-library exact replay.
