#!/usr/bin/env python3
"""NONRIGOROUS reconnaissance only; no reported number is an enclosure.
One K evaluation per product after analytic integration by parts. Computes
V2(R)=integral_R^b (s-R)H(s)ds-3 integral_R^b J(s)ds,
H=4*pi^2*exp(5s)*sum p^2 C_p [((p*z)^2-6)sinh(a*s)-3a*cosh(a*s)]K_it(pz),
J=4*pi^2*exp(5s)*sinh(a*s)*sum p^2 C_p K_it(pz), a=7/8.
All infinity/product truncations and Simpson errors UNVALIDATED in this script.
"""
import mpmath as mp, numpy as np, json, time, sys, hashlib, pathlib
from scipy.integrate import cumulative_simpson
from concurrent.futures import ProcessPoolExecutor

def job(par):
    t,N=par; mp.mp.dps=45; start=time.time();a=mp.mpf(7)/8
    zmax=max(2*t,t+80); b=float(mp.log(zmax/(2*mp.pi))/2)
    grid=np.linspace(0,b,N+1); phases={};rows=[]
    scale=mp.exp(mp.pi*t/2)/mp.mpf(t)**4
    for r in grid:
        r=mp.mpf(float(r));z=2*mp.pi*mp.exp(2*r)
        pmax=int(mp.ceil(zmax/z));sumK=mp.mpf(0);sumZK=mp.mpf(0)
        for p in range(1,pmax+1):
            if p not in phases:
                phases[p]=mp.fsum(mp.cos(t*mp.log(mp.mpf(p)/(d*d))) for d in range(1,p+1) if p%d==0)
            w=p*z; K=mp.re(mp.besselk(mp.mpc(0,t),w));v=p*p*phases[p]*K
            sumK+=v;sumZK+=w*w*v
        sh=mp.sinh(a*r);ch=mp.cosh(a*r);pr=4*mp.pi**2*mp.exp(5*r)*scale
        J=pr*sh*sumK;H=pr*(sh*(sumZK-6*sumK)-3*a*ch*sumK)
        rows.append([float(H),float(J)])
    vals=np.array(rows); H=vals[:,0];J=vals[:,1]
    # Smooth cumulative Simpson quadrature; floats only for this diagnostic.
    IH=cumulative_simpson(H,x=grid,initial=0);IsH=cumulative_simpson(grid*H,x=grid,initial=0)
    IJ=cumulative_simpson(J,x=grid,initial=0)
    V=(IsH[-1]-IsH)-grid*(IH[-1]-IH)-3*(IJ[-1]-IJ)
    # Ignore far-right tiny differences vulnerable to cumulative subtraction.
    stop=np.searchsorted(grid,float(mp.log(mp.mpf(5)*t/(8*mp.pi))/2))
    idx=int(np.argmin(V[:stop]));out={'status':'NONRIGOROUS_RECON_ONLY','t':t,'N':N,'b':b,'zmax':zmax,'dps':45,
      'scale':'exp(pi*t/2)/t^4','seconds':time.time()-start,'minimum':{'R':float(grid[idx]),'V2_scaled':float(V[idx])},
      'V2_scaled_R0':float(V[0]),'negative_samples':int(np.sum(V[:stop]<0)),
      'rows':[{'R':float(r),'H':float(h),'J':float(j),'V2_scaled':float(v)} for r,(h,j),v in zip(grid,rows,V)]}
    p=pathlib.Path('/mnt/data/rh_next_review/results')/f'recon_t{t}_N{N}.json';p.write_text(json.dumps(out,indent=2))
    print(t,out['minimum'],'at0',out['V2_scaled_R0'],'negative',out['negative_samples'],'s',out['seconds'],flush=True)
    return {k:v for k,v in out.items() if k!='rows'}
if __name__=='__main__':
    ts=[int(s) for s in sys.argv[1].split(',')] if len(sys.argv)>1 else [35,40,50,80]
    N=int(sys.argv[2]) if len(sys.argv)>2 else 240
    with ProcessPoolExecutor(max_workers=4) as pool:
        result=list(pool.map(job,[(t,N) for t in ts]))
    pathlib.Path('/mnt/data/rh_next_review/results/recon_summary_'+sys.argv[1]+'.json').write_text(json.dumps(result,indent=2))
