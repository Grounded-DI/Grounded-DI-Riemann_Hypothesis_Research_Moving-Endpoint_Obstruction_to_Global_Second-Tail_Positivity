"""Heuristic Mellin/turning-region reconnaissance, NOT a proof or enclosure."""
import numpy as np, json, math, pathlib
N=1000000
spf=np.arange(N+1);Omega=np.zeros(N+1,dtype=np.int32);d=np.ones(N+1,dtype=np.int64)
for p in range(2,N+1):
 if spf[p]==p:
  spf[p*p::p]=np.minimum(spf[p*p::p],p)
for n in range(2,N+1):
 p=spf[n];v=n//p;Omega[n]=Omega[v]+1;e=1
 while v%p==0:e+=1;v//=p
 d[n]=d[v]*(e+1)
n=np.arange(1,N+1);sig=15/16;a=d[1:]*(1-2*(Omega[1:]%2))*n**(-sig)
S=np.cumsum(a);L=np.cumsum(a*np.log(n));res=[]
for X in [10,20,50,100,200,500,1000,2000,5000,10000,100000,1000000]:
 val=math.log(X)*S[X-1]-L[X-1];res.append([X,val]);print(X,val)
pathlib.Path('/mnt/data/rh_next_review/results/dirichlet_liouville_recon.json').write_text(json.dumps({'sigma':sig,'status':'HEURISTIC_MODEL_NOT_ACTUAL_V2','values':res},indent=2))
