# Review record and remaining obligations

## Outcome

ADVANCE — new analytic obstruction to the proposed all-height/all-endpoint second-tail nonnegativity route. Not a counterexample to the supplied positive cone; not a disproof of RH.

## Supported scope

For arbitrarily large positive real t, the actual-theta second tail is strictly negative at R=(1/2)log(t/(448*pi)). This follows from the complete proof in the report and exact finite inequalities, under ordinary analysis and disclosed integer/rational software trust. No numerical negative (t,R) pair is claimed.

## Distinct verification categories

- Integrity: incoming ZIP hash, byte count, CRCs and 114 payload entries checked; successor payloads separately manifested.
- Reproducibility: two finite-sign methods execute; the producer's fresh mathematical record matches after timestamp/runtime exclusion. Four additional selected corruptions are rejected.
- Mathematical correctness: depends on the written theta expansion, full Mellin transform, phase-uniform dominated convergence, finite sign and continuous-time recurrence argument. The replay does not formally verify these universal statements.

## Main adversarial attacks

The proof explicitly bounds the complete vertical gamma ratio, including frequencies near plus/minus t. The phase-dependent Dirichlet factor is uniformly bounded on Re(s)=2, permitting a single error bound even while phases vary. Products are not truncated: exact Mellin inversion converts the full product sum into the finite logarithmic polynomial. The Bessel derivative contributes t^2+(mu-3)^2, and an alternate endpoint integration-by-parts calculation confirms the same coefficient. The lower-order second monomial is retained until its normalized contribution is shown to vanish. The continuous-time recurrence proof is not replaced by a false discrete-time independence claim. Every negative conclusion has a strict margin.

## Independent-code limits

The exact certifier uses integer-root bisection and an atanh-series log bound. The separate checker uses direct divisor counts, a prime-power multiplicity sieve, checked integer-root witnesses, and exact-rational Simpson log bounds. Both were written by one assistant, share Python, and use the same definitions. No independent agent or human proof review was available.

## Previous gate not silently promoted

No preserved local successor work from the interrupted request was present at initial inventory. The historical specialist materials were inside the incoming source package. No full fresh [33,34] Arb rectangle/seed audit was performed because python-flint could not be installed. That earlier Stage 1 is not reported as completed. The new analytic argument is self-contained from the definitions and uses none of those finite-height conclusions as premises.

## Preserved failures and limitations

The python-flint installation failure and uncertified reconnaissance are preserved. The incoming archive's older D output/log overwrite, A diagnostic transcription and B first-run provenance omissions remain disclosed. Nothing here recovers missing historical bytes.

No new mathematical defect requiring a silent repair was found in the cone. The new proof was drafted and reviewed before freezing; proof-document citation/layout edits did not alter any executed certificate source. The production certificate and checker sources remain bound to their first recorded hashes.

## Unresolved obligations

1. External independent expert review and/or formalization of the phase-uniform Mellin argument and recurrence-to-negativity implication.
2. An effective asymptotic threshold and explicit certified negative height, optionally the first such height. Neither 224 nor a height threshold is claimed optimal.
3. The weaker aggregate transform sign with the signed compact contribution and V2(0) boundary term retained.
4. The inherited theta-to-xi identity is contextual in this report, not a premise of the new theorem; a full new audit of the final RH bridge was not performed.
5. Any justified descent from a global initial fixed strip to the critical line.
6. The prior full Stage 1 independent numerical review, if still desired as a separate historical-validation task.

The correct classification of the obstruction is mathematical, not merely a seed-curvature estimate, finite precision, or certification-cost limitation.
