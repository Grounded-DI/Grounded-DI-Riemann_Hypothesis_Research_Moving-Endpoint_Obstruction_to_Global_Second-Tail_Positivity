# Primary mathematical sources

Retrieved with the web tool during this run. The new limiting and phase-transfer arguments are derived in the report; they are not claims attributed to these source pages.

**DLMF 10.32.9** — https://dlmf.nist.gov/10.32.E9

Use and checked hypothesis: Bessel full-line integral; positive z, imaginary order.

**DLMF 10.32.10** — https://dlmf.nist.gov/10.32.E10

Use and checked hypothesis: Schlaefli integral; positive z satisfies |arg z|<pi/4.

**DLMF 10.43.19** — https://dlmf.nist.gov/10.43.E19

Use and checked hypothesis: Mellin moment; Re(mu)>|Re(i*t)|=0.

**DLMF 5.11** — https://dlmf.nist.gov/5.11

Use and checked hypothesis: Stirling/gamma growth in vertical sectors; constants may depend on fixed real part.

**DLMF 5.11.12** — https://dlmf.nist.gov/5.11.E12

Use and checked hypothesis: Gamma ratios for fixed complex shifts, sectors away from negative real axis.

**DLMF 3.5.8** — https://dlmf.nist.gov/3.5.E8

Use and checked hypothesis: Composite Simpson exact remainder; n=64 even and 1/u in C^4[1,y].

**DLMF 1.8** — https://dlmf.nist.gov/1.8

Use and checked hypothesis: C^2 Fourier coefficient decay and convergence; supports the explicitly proved continuous phase recurrence.

**DLMF 10.25.1** — https://dlmf.nist.gov/10.25.E1

Use and checked hypothesis: Modified-Bessel ODE for cone review.

**DLMF 25.4** — https://dlmf.nist.gov/25.4

Use and checked hypothesis: Xi definition and functional equation; context only, not an obstruction premise.
