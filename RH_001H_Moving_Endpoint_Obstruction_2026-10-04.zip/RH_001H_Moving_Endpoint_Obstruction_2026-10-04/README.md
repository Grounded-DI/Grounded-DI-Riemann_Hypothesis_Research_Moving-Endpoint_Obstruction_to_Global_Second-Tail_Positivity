# MathWise RH-001H — moving-endpoint obstruction

**ADVANCE — an analytic obstruction theorem, not an RH proof.**

Prepared for Mark S. Weinstein; AI-assisted, private review; 4 October 2026 UTC.

## Read first

The complete 15-page proof and review are in `RH_001H_Moving_Endpoint_Obstruction_2026-10-04.pdf`; editable mathematical source is `proof/obstruction.tex`.

For every H>0, the new argument proves there exists a real t>max(H,448*pi) with

    R = (1/2) log(t/(448*pi)) > 0
    V_(2,t)(R) < -(C*/100) t^(63/16) exp(-pi*t/2) < 0,
    C* = pi^3 / (2 (2*pi)^(47/16)).

This is an analytic existence theorem. No explicit negative height, first negative height, or effective asymptotic threshold is provided. The exact numerical certificate concerns a 223-term divisor polynomial, not a direct evaluation of V2 at a particular height.

The incoming positive cone is not contradicted: it applies at 2*pi*exp(2R)>=5*|t|/4; the negative endpoints are at 2*pi*exp(2R)=t/224. The new theorem refutes blanket all-height/all-endpoint V2 nonnegativity, a stronger sufficient route to the aggregate-transform target. It does not settle that weaker transform target or RH.

## Proof dependencies

1. The actual theta definitions yield the full divisor/Bessel expansion and exact endpoint integral.
2. Mellin inversion and gamma bounds give a moving-endpoint scaling limit whose error is uniform in changing divisor phases.
3. Exact arithmetic proves D_224 < -3/100 and a phase-sensitivity constant B_224 <156.
4. If all 48 prime phases are within 1/100 of pi, the finite polynomial is <-9/625.
5. A continuous-time Fourier averaging argument proves this phase neighborhood recurs at arbitrarily large real heights. The uniform scaling error then transfers strict negativity to the actual V2.

The proof does not use the finite-height Arb certificates, assume RH, or continue zeta outside an absolutely convergent Dirichlet half-plane.

## Replay

Only ordinary Python 3 and the standard library are needed for the exact finite certificates. Do not use `-O` or `PYTHONOPTIMIZE`; assertions are part of the checks.

```sh
python code/replay.py /path/to/a/NEW/replay-directory
```

The destination must not exist. Four commands regenerate the finite certificate, reconstruct its sign using a different logarithm algorithm, check the reviewed cone's finite constants, and check finite divisor-phase algebra. Actual fresh outputs from this run are retained under `results/replay_001/`. Mathematical certificate content matches the original after excluding run-specific timestamps and Python version; no byte-identical timestamped-file claim is made.

Optional selected corruption tests:

```sh
python code/mutation_checks.py /path/to/a/NEW/mutation-directory
```

The four retained mutations are rejected by the separate checker. This does not constitute universal tamper detection or a formal proof of the analytic lemmas.

## Independence and what did not run

One assistant wrote the proof, performed the adversarial review, and wrote both arithmetic implementations. Four concurrent diagnostic processes were not four independent AI specialists. The arithmetic implementations share Python and checked root witnesses; their logarithm and counting paths differ. No independent human or formal-kernel review has occurred.

The incoming cone ZIP's 72,771,333 bytes, CRCs, and all 114 payload hashes passed this run's integrity checks. Its analytic proof was reconstructed with no defect found. Python-flint was unavailable and package download failed. Therefore no fresh Arb evaluation, no full 800-rectangle [33,34] replay, and no completed retrospective Stage 1 independent numerical audit are claimed here. The new analytic result does not depend on those missing checks.

## Evidence preservation

`provenance/incoming_cone/` contains byte-preserved selected source documents, the source report, manifest, sidecar, and integrity JSON. Full uploaded predecessors remain unchanged in the original conversation; their complete bytes are not duplicated in this compact successor. `provenance/INPUT_IDENTITIES.json` binds them by filename, size, and SHA-256.

`diagnostics/` preserves uncertified reconnaissance, including four positive sampled grids. These are not mathematical premises. `review/REVIEW_RECORD.md` states unresolved obligations and provenance limitations. The root manifest identifies every frozen successor payload, excluding the manifest itself; the external ZIP sidecar identifies the finished archive.

No publication, public-repository write, outside contact, or submission was performed. Historical novelty, causal Protocol A benefit, and an RH advance are not claimed.
