# An explicit infinite-height cone for the actual-theta kernel

Source-informed, AI-assisted mathematical research commissioned by Mark S. Weinstein. Prepared 4 October 2026 UTC for private review. This is a bounded mathematical follow-up, without a historical-novelty, independent-human-review, formal-verification or causal Protocol A claim.

## P1. Result and definitions

**Theorem.** Retain the RH-001H actual-theta normalization below. For every real t with tau = |t| >= 34,

\[
g_t(r)>0\quad\text{whenever}\quad z=2\pi e^{2r}\ge\frac54\tau.
\tag{1}
\]

Consequently,

\[
V_{2,t}(R)>0\quad\text{for every}\quad
R\ge R_c(\tau):=\frac12\log\frac{5\tau}{8\pi}.
\tag{2}
\]

The proposed coefficient 2 therefore works, and the permitted refinement 5/4 also works. No optimality is asserted. The new cone proof is analytic; no finite Bessel evaluation, numerical grid or Arb enclosure is a premise of (1)-(2).

The supplied, inherited normalization is

\[
g_t(r)=4\pi^2e^{5r}\sinh(7r/8)S_t(z),\quad
S_t(z)=\sum_{p\ge1}p^2C_p(t)B_t(pz),
\]
\[
C_p(t)=\sum_{d\mid p}\cos\left(t\log\frac{p}{d^2}\right),\quad
B_t(w)=(w^2+9)K_{it}(w)+6wK'_{it}(w).
\tag{3}
\]

Here p ranges over all positive integer products, not primes; d ranges over all positive divisors. In particular C_1=1. The argument of the p-th Bessel block is pz, distinct from the leading argument z. Set q(w)=exp(-w)sqrt(pi/(2w)). The normalization is bound to the immediate predecessor, `agents/A_AFFINE_SEED_PROOF.md` (A3), whose containing archive is preserved. This mission proves the analytic estimates from that expansion and does not describe the inherited theta/Fourier derivation as a fresh independent derivation.

## P2. Exact shifted representation

NIST DLMF equation [10.32.9](https://dlmf.nist.gov/10.32.E9), valid for |arg z| < pi/2 and complex order, gives for positive real z

\[
K_{i\tau}(z)=\frac12\int_{\mathbb R}e^{-z\cosh u+i\tau u}\,du.
\tag{4}
\]

Fix any finite pair tau >= 34, z >= 5tau/4. Define

\[
\theta=\arcsin(\tau/z),\qquad
a=z\cos\theta=\sqrt{z^2-\tau^2}.
\]

Then 0 < theta <= arcsin(4/5) < pi/2, a >= 3tau/4 >= 51/2. Shift the entire integrand in (4) to the horizontal line u+i theta. On either vertical edge at real part +/-L and imaginary part v in [0,theta], its modulus is

\[
e^{-z\cosh L\cos v-\tau v}\le e^{-a\cosh L}.
\]

Each vertical integral is at most theta exp(-a cosh L), tending to zero. The shifted horizontal integrand is absolutely integrable, bounded by exp(-a cosh u-tau theta). Cauchy's theorem on each finite rectangle followed by these limits is therefore legitimate. Since z sin theta=tau, symmetry of the real amplitude and odd phase yields the exact identity

\[
K_{i\tau}(z)=e^{-\tau\theta}\int_0^\infty
e^{-a\cosh u}\cos\{\tau(u-\sinh u)\}\,du.
\tag{5}
\]

This establishes (5) for an arbitrary finite pair; the bounds below use constants uniform over the entire unbounded cone. No parameter supremum is exchanged with a limiting contour integral.

## P3. The entire phase loss

For u >= 0, the integral Taylor remainder gives

\[
0\le\sinh u-u=\frac12\int_0^u(u-v)^2\cosh v\,dv
\le\frac{u^3\cosh u}{6}.
\]

Also tanh u <= u, hence log cosh u <= u^2/2 and cosh^2 u <= exp(u^2). Together with 1-cos v <= v^2/2 and cosh u >= 1+u^2/2, these give for a>2

\[
\begin{aligned}
L(a,\tau)&:=\int_0^\infty e^{-a\cosh u}
[1-\cos\{\tau(u-\sinh u)\}]\,du\\
&\le\frac{\tau^2e^{-a}}{72}\int_0^\infty
u^6e^{-(a-2)u^2/2}\,du\\
&=\frac{5\tau^2e^{-a}\sqrt{\pi/2}}{24(a-2)^{7/2}}.
\end{aligned}
\tag{6}
\]

The Gaussian moment is obtained by three integrations by parts from the half-line Gaussian integral; all boundary terms vanish because a-2>0. The zeroth Gaussian integral follows by squaring the integral and using polar coordinates. This bounds the complete adverse oscillatory contribution, including the entire outer half-line.

For 0<=u<=1, the cosh series gives cosh u-1 <= u^2(cosh 1-1)<=u^2, with the last inequality strict when u>0. The elementary exponential-series estimate

\[
e<\frac52+\frac16\sum_{k\ge0}4^{-k}
=\frac{49}{18}<\frac{11}{4}<3
\tag{7}
\]

uses n! >= 6*4^(n-3) for n>=3; it also implies cosh 1<2. Thus the positive nonoscillatory integral has the lower bound

\[
K_0(a)=\int_0^\infty e^{-a\cosh u}\,du
\ge\frac{e^{-a-1}}{\sqrt a}.
\tag{8}
\]

This restriction to u in [0,1/sqrt(a)] is applied only to K_0, whose integrand is positive. Equation (5) is exactly exp(-tau theta)[K_0(a)-L(a,tau)], so no uncharged oscillatory tail is discarded.

The elementary integral estimate

\[
\pi=4\int_0^1\frac{dx}{1+x^2}
<4\int_0^1(1-x^2+x^4)dx
=\frac{52}{15}<\frac{32}{9}
\tag{9}
\]

gives sqrt(pi/2)<4/3. On our cone, tau^2/a^2<=16/9 and a>=51/2. Both 1/a and a/(a-2) decrease for a>2; consequently

\[
\begin{aligned}
e^a\sqrt a\,L(a,\tau)
&\le\frac{10\sqrt{\pi/2}}{27a}
\left(\frac{a}{a-2}\right)^{7/2}\\
&<\frac{10}{27}\frac43\frac2{51}
\left(\frac{51}{47}\right)^4
=\frac{393040}{14639043}<\frac1{36}.
\end{aligned}
\tag{10}
\]

Combining (5), (7), (8), (10) proves the uniform lower bound

\[
K_{i\tau}(z)>
\underbrace{\left(\frac4{11}-\frac1{36}\right)}_{133/396>1/3}
\frac{e^{-a-\tau\theta}}{\sqrt a}.
\tag{11}
\]

This establishes the requested one-third Bessel bound on the stronger cone. For the original coefficient-2 cone, the preserved A proof obtains the stronger coefficient 789/2200 by bounding the relative loss by 1/200; that original proof was approved before the optional refinement began.

For normalization, pi>2 follows directly from the integral in (9), so 1<pi/2. The alternating sine series gives sin 1>1-1/6=5/6>4/5. Thus theta<=arcsin(4/5)<1. From a<=z, tau<=4z/5 and (9),

\[
\frac{K_{i\tau}(z)}{q(z)}>
\frac13\sqrt{\frac{2z}{\pi a}}e^{z-a-\tau\theta}
>\frac14e^{-4z/5}.
\tag{12}
\]

The quarter coefficient uses pi<32/9 explicitly; pi<4 alone would not justify it from the weaker one-third coefficient.

## P4. The ODE and complete product remainder

The primary differential equation [DLMF 10.25.1](https://dlmf.nist.gov/10.25.E1), with order i tau, implies for y(w)=sqrt(w)K_(i tau)(w)

\[
y''(w)=\left(1-\frac{\tau^2+1/4}{w^2}\right)y(w).
\tag{13}
\]

Equation (11) already proves y>0 throughout w>=5tau/4. This domain is also above the turning point: ((5/4)^2-1)tau^2>1/4. Positivity here is not an assumption taken from the desired kernel conclusion.

From the unshifted integral and dominated differentiation,

\[
|K_{it}(w)|\le K_0(w)\le q(w),\qquad
|K'_{it}(w)|\le K_1(w)\le q(w)(1+1/(2w)).
\tag{14}
\]

The first Gaussian bound follows from cosh u>=1+u^2/2. For the second, v=sinh(u/2) gives

\[
K_1(w)=2e^{-w}\int_0^\infty
\frac{1+2v^2}{\sqrt{1+v^2}}e^{-2wv^2}\,dv
\le q(w)(1+1/(2w)).
\]

These estimates give y,y' -> 0 exponentially for each fixed tau. Put W(w)=e^(-w)(y'+y). Then

\[
W'(w)=-(\tau^2+1/4)e^{-w}y(w)/w^2<0,
\quad W(\infty)=0,
\]

so W(w)=integral_w^infinity (tau^2+1/4)e^(-s)y(s)/s^2 ds>0. Hence

\[
K'_{i\tau}(w)/K_{i\tau}(w)>-1-1/(2w),\qquad
B_t(w)>(w^2-6w+6)K_{it}(w).
\tag{15}
\]

The boundary at infinity is retained. This shorter proof needs only the positivity already established on the cone. B's separate energy argument in `B_KERNEL_PROOF.md` (K9)-(K12) reconstructs the wider turning-point positivity region without a uniform-order asymptotic.

For every real t and w>0, (14) gives

\[
|B_t(w)|\le q(w)(w^2+6w+12).
\tag{16}
\]

Let d(p) be the divisor count. Since |C_p(t)|<=d(p)<=p and q(pz)/q(z)=p^(-1/2)e^(-(p-1)z),

\[
\frac{p^2|C_p(t)B_t(pz)|}{z^2q(z)}
\le p^{9/2}e^{-(p-1)z}
\left(1+\frac6z+\frac{12}{z^2}\right).
\tag{17}
\]

The power 9/2 includes the outer p^2, divisor bound p, Gaussian factor p^(-1/2), and leading block p^2. For p>=2, the ratio of successive majorants is at most rho(z)=(3/2)^(9/2)e^(-z). Therefore the complete p>=2 remainder obeys

\[
\frac{\left|\sum_{p\ge2}p^2C_p(t)B_t(pz)\right|}{z^2q(z)}
\le E(z):=\left(1+\frac6z+\frac{12}{z^2}\right)
\frac{2^{9/2}e^{-z}}{1-(3/2)^{9/2}e^{-z}}.
\tag{18}
\]

On z>=85/2, the first factor is <3/2, 2^(9/2)<32, and rho<8/e^6<1/2 since e>2. Thus E(z)<96e^(-z), with positive geometric denominator. Also 1-6/z+6/z^2>1/2. Equations (12), (15), (18), and C_1=1 give

\[
\frac{S_t(z)}{z^2q(z)}>
\frac18e^{-4z/5}-96e^{-z}>0.
\tag{19}
\]

For the last strict inequality, z/5>=17/2 and

\[
e^{z/5}\ge e^{17/2}>
\sum_{k=0}^6\frac{(17/2)^k}{k!}
=\frac{58017253}{46080}>768.
\tag{20}
\]

Thus the leading term dominates every possible adverse divisor contribution. Because z>=85/2>2pi implies r>0, the prefactor in (3) is positive. This proves (1).

## P5. Convergence, evenness, tails and the transform

Equations (16)-(17) imply locally uniform absolute convergence of the series for r>=0, uniformly in real t: z>=2pi and a polynomial in p times exp(-2pi(p-1)) is summable. For large r they give constants independent of real t such that

\[
|g_t(r)|\le C\exp\{71r/8-2\pi e^{2r}\}.
\tag{21}
\]

Indeed the outer factor contributes exp(47r/8) and z^2q(z) contributes a constant times exp(3r-2pi exp(2r)). This bound remains integrable after multiplication by any fixed exponential in r and any polynomial in r. It justifies all tail integrals and the absolute Fubini identity

\[
\int_R^\infty V_{1,t}(s)ds
=\int_R^\infty(u-R)g_t(u)du=V_{2,t}(R).
\tag{22}
\]

For R>=R_c(tau), g_t(u)>0 throughout u>=R; the weight u-R>0 on (R,infinity). Continuity and (21) therefore prove strict positivity in (2), including at R=R_c. The functions C_p(t), K_it, B_t, g_t and their convergent tails are even in t, either directly from cosine representations or K_it=K_-it. This explains the absolute-height scope.

The inherited theta/Fourier identification is Hhat_x(t)=integral_0^infinity sinh(2xr)g_t(r)dr. To verify its tail reformulation, use V_1'=-g and V_2'=-V_1. For f(r)=sinh(2xr) and finite b,

\[
\int_0^b f g\,dr=-[fV_1]_0^b-[f'V_2]_0^b+\int_0^b f''V_2\,dr.
\tag{23}
\]

For any fixed L>2|x|, (21) gives |g(s)|<=C_L exp(-Ls) eventually, and thus |V_1(b)|<=C_L exp(-Lb)/L and |V_2(b)|<=C_L exp(-Lb)/L^2. Both upper boundary terms vanish as b tends to infinity, including for 0<x<=1/16. Since f(0)=0 and f'(0)=2x, this gives

\[
\widehat H_x(t)=2xV_{2,t}(0)+4x^2\int_0^\infty
\sinh(2xr)V_{2,t}(r)\,dr.
\tag{24}
\]

The new theorem makes the part of the integral above R_c positive. It determines neither V_2(0) nor the omitted compact contribution. If all-endpoint positivity at a fixed t were separately proved, (24) would be strictly positive for 0<x<=1/16. The predecessor's report, p. 8, identifies this transform with

\[
\widehat H_x(t)=\frac18\left(
|\xi(15/16+x+it)|^2-|\xi(15/16-x+it)|^2\right).
\tag{25}
\]

Under that inherited identity, strict transform positivity would exclude a zero at the right evaluation point. At x=0 the difference is zero, so no strict boundary claim follows. This mission adds no all-height transform conclusion. All-height second-tail positivity, aggregate transform positivity, a global initial fixed strip and descent to RH remain separate obligations.

## P6. Scope, checks and independent reconstruction

All infinite quantifiers in this proof are controlled by explicit analytic estimates. Exact Fraction programs check the finite rational constants in (7), (9)-(12), (18)-(20). They do not machine-prove contour shifting, the Gaussian integral, differential inequalities, convergence or the unbounded conclusion. The preserved A/B/C/D notes record separate reconstructions with shared definitions and discussion; D also gives a different Gaussian K_0 baseline proving the same stronger cone. Those are within-workflow checks, not independent human review or independent validated-backend verification.

The newly reconstructed theorem (1)-(2) uses no numerical interval premises. The inherited finite-height theorems and the newly replayed T=34,Z=35 comparison/point seed retain their stated Arb/FLINT trust model. The smallest inherited compact lower bound is not a lower bound on the infinite tail, which tends to zero.

The new moving cutoff is R_c(tau). For 34<tau<=64, the older |t|<=64 theorem can be stronger: its threshold is L(65)=log(65/(2pi))/2. The exact crossover is tau=52. `COVERAGE_RECORD.json` and `COVERAGE.md` record the union, rather than replacing better inherited coverage. Historical novelty has not been investigated.
