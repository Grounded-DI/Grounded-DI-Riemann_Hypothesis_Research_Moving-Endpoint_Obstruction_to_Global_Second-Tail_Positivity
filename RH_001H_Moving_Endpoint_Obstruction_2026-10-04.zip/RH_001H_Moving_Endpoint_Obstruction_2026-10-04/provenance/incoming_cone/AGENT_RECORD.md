# Assignments, review and provenance

One coordinator and four specialists were used. All shared the same immutable, verified predecessor snapshot and the supplied normalization. The primary coefficient-2 proof was completed and adversarially approved before the coordinator authorized the coefficient-5/4 refinement.

| Role | Distinct assignment | Delivered reconstruction |
|---|---|---|
| Coordinator | Bind sources, preserve predecessors, select proof and replay decisive checks | Complete PROOF.md; independent 21-constant checker; fresh underlying baseline; every official A/B/C checker replayed |
| A | Shifted contour and entire phase loss | A_SADDLE_PROOF.md; separate A_OPTIONAL_CONE.md; 7+14 finite checks |
| B | ODE logarithmic derivative and complete product remainder | B_KERNEL_PROOF.md; separate turning-point energy argument; 9 finite checks |
| C | Independent constants and reproducibility | C_CONE_PROOF.md; distinct primary constants and independently reconstructed optional route; 32+31 finite checks |
| D | Adversarial derivations, quantifiers and executed source review | D_review.md; independent Gaussian K0 baseline; review of full A/B/C proofs, root proof, actual code and results |

The optional central-mass route was proposed by the coordinator and separately reconstructed by A, C and D. D's Gaussian baseline is a different analytic derivation of the same cone, sharing the primary Bessel integral, differential equation and definitions. These are within-team AI checks. No independent human expert review, blind replication, proof-assistant verification or independently validated arithmetic backend is claimed.

## Substantive review points

1. **Normalization constant.** A one-third lower Bessel coefficient and only pi<4 do not imply the needed quarter normalized coefficient. The primary proof retains 789/2200; the optional proof explicitly proves pi<52/15<32/9. This removes a potential constant gap.
2. **Entire oscillatory half-line.** The proof bounds K0(a) minus the complete phase loss. It never discards the unexamined outer oscillatory integral.
3. **ODE boundary and circularity.** Positivity of K is established before the Wronskian argument. The limit W(infinity)=0 is proved by global absolute bounds, and the integral from w to infinity is retained.
4. **Endpoint strictness notation.** An early A/C sentence wrote a strict cosh inequality at u=0. It was corrected to nonstrict there and strict for u>0. No numerical bound or conclusion changes.
5. **Coverage union.** New-cone coverage alone would lose the better old |t|<=64 tail cutoff for 52<|t|<=64. The final ledger retains that older region.

No unresolved mathematical objection to the new cone theorem remains in the recorded adversarial review. This is a statement about this bounded review, not a guarantee of error-free mathematics.

## Preservation limitations

The inherited first D structural-check output/log from the adjacent-band mission was overwritten before this mission. Its source was reconstructed with a matching recorded hash. Those missing original bytes have not been recovered; final outputs and the complete underlying replay remain preserved in the predecessor.

Two new small execution-record exceptions are disclosed:

- B's first nine-Fraction run did not save a separate pre-execution hash record or stderr. The executed program emitted a source hash that matches the preserved source. B_run_001 is explicitly a post-execution preservation record. The coordinator then performed a fresh prehashed replay with actual stdout/stderr.
- A ran an inline three-expression rational diagnostic without a pre-run source hash or separately recorded elapsed time. A_DIAGNOSTIC_PROVENANCE.md and A_diagnostic_002 label the source/output as later transcriptions, not recovered original execution captures. A subsequently ran the official frozen 14-check program; the coordinator freshly replayed that program too. A one-second unmeasured budget allowance is recorded for the diagnostic.

No earlier source or output was silently overwritten in this mission. The noted omissions are distinct from the original predecessor's overwritten output. Pre-run provenance cannot be retroactively manufactured; fresh replay establishes a new execution record. Every delivered official executed source version is retained with its actual recorded results.
