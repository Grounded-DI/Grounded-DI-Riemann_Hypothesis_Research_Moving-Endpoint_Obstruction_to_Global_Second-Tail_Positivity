# Source locations and hypotheses

Retrieved 4 October 2026. Material special-function formulas were checked at the primary NIST DLMF equation locators. General elementary integration, power-series and contour arguments are reconstructed in PROOF.md; no imported classification or uniform large-order asymptotic is needed.

| Source | Exact location | Hypotheses and use |
|---|---|---|
| [NIST DLMF, modified Bessel integral](https://dlmf.nist.gov/10.32.E9) | Equation 10.32.9; displayed equation and sector condition at retrieved lines 147-148 | Complex order allowed; positive real z satisfies abs(arg z)<pi/2. Used with order i tau. Full-line form and contour shift reconstructed in PROOF.md P2. |
| [NIST DLMF, modified Bessel equation](https://dlmf.nist.gov/10.25.E1) | Equation 10.25.1; retrieved line 40 | Set order nu=i tau and positive real argument. Transformation y=sqrt(z)K and boundary argument reconstructed in P4. |
| [MathWise pinned main](https://github.com/Grounded-DI/MathWise/tree/192c83d28fd716b2deb6f8cb750aafb4dd994dd7) | Exact commit 192c83d28fd716b2deb6f8cb750aafb4dd994dd7 | Current ref fetched read-only. It equals the predecessor pin; no intervening main changes observed. Local attached follow-ups are bound by hashes, not asserted to be published at that commit. |
| Immediate predecessor archive | SHA-256 bb01dc6baaccaf6ff4d723bdd78a03b525b914e1a2564043e4f8e44eb30202d0; root rh_v2_adjacent/ | A_AFFINE_SEED_PROOF.md (A3): theta expansion; (A1)-(A2): finite T34/Z35 tail comparison; C_direct_tail.py: original-B seed evaluation. |
| Immediate predecessor report | rh_v2_adjacent/REPORT_TEXT.txt, PDF pp. 6-8; COVERAGE_RECORD.json | Complete [31,34] all-R inherited coverage, compact constant scope, and squared-xi/Fourier identity. Only the stated baseline subset is newly rerun. |
| Nested [31,33] predecessor | rh_v2_adjacent/predecessors/RH_001H_V2_Height_Band_31_33_2026-10-04.zip; inner rh_v2_band/COVERAGE_RECORD.json | Preserved L(33), L(34), L(65) tail regions. Its ZIP hash is e010706ababe50a51397ef09b5b6f7b011eb1bdcb01e3b550134def457e9fdb7. |

The current theorem needs (3), DLMF 10.32.9 and 10.25.1 plus the explicit analysis in PROOF.md. It has no unresolved imported special-function premise within this scope. The earlier theta/Fourier/xi normalization is carried forward with a precise source binding, not claimed to have been independently derived again. The broader RH program's unproved obligations are listed separately.
