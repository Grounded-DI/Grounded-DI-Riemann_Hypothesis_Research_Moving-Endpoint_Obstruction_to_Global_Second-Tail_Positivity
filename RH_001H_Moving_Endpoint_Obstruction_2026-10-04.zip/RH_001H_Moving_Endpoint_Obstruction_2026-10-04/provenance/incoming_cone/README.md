# RH-001H: unbounded-height cone follow-up

Prepared 4 October 2026 for Mark S. Weinstein. Private review package; no publishing or repository modifications.

**Result:** for every tau=|t|>=34, the complete actual-theta kernel is positive when z=2pi exp(2r)>=5tau/4. Consequently V2,t(R)>0 for R>=log(5tau/(8pi))/2. The full proof is analytic. Exact computations check finite constants and a relevant inherited numerical baseline.

Start with the companion PDF and PROOF.md. COVERAGE.md gives the precise union with stronger inherited regions. PRIMARY_SOURCES.md locates imported formulas. CLAIM_TO_EVIDENCE.csv/CLAIM_LEDGER.json, DEPENDENCY_MAP.json, ERROR_ACCOUNTING.md and AGENT_RECORD.md distinguish proof, numerical results, inherited assumptions and limitations. PROPOSED_MATHWISE_ADDENDUM.md is an unpublished draft.

## Reproduce the new finite checks

From a fresh extraction's parent directory, with Python 3.12:

```sh
python rh_v2_cone/run_frozen_checks.py rh_v2_cone/runs/user_replay_001 rh_v2_cone/cone_exact_check.py rh_v2_cone/agents/A_saddle_constants_v1.py rh_v2_cone/agents/B_exact_constants.py rh_v2_cone/agents/A_optional_constants_v1.py rh_v2_cone/agents/C_constants.py rh_v2_cone/agents/C_optional_constants.py
```

Choose a previously nonexistent run directory. The driver refuses to reuse one, freezes every source and writes hashes before execution, then preserves actual stdout/stderr and checks source hashes afterward. Expected counts are 21,7,9,14,32,31, all PASS (114 comparisons). The original agent executions separately contain93 comparisons. Source-path and timing fields can differ on replay; compare mathematical records separately. This does not machine-prove PROOF.md.

## Reproduce the selected predecessor calculation

The complete immediate predecessor and all nested predecessors are preserved under predecessors/. The working snapshot is omitted from the successor ZIP to avoid duplicating the same large archives. Extract it once:

```sh
python -m zipfile -e rh_v2_cone/predecessors/RH_001H_V2_Affine_Seeds_Band_33_34_2026-10-04.zip rh_v2_cone/snapshot
```

Use Python3.12.14 with python-flint0.9.0/FLINT3.6.0 to match the recorded environment. No other package is needed for the exact Fraction checks. The archived source snapshots can be rerun without overwriting their outputs:

```sh
mkdir rh_v2_cone/runs/user_baseline_001
python rh_v2_cone/runs/coordinator_baseline_001/A_tail_threshold.py > rh_v2_cone/runs/user_baseline_001/tail.json
python rh_v2_cone/runs/coordinator_baseline_001/C_direct_tail.py --t 34 --R 7/8 --pmax 2 --Z 100 --prec 256 --rel-tol 1e-18 --abs-tol 1e-65 --output rh_v2_cone/runs/user_baseline_001/endpoint.json > rh_v2_cone/runs/user_baseline_001/endpoint.log
```

The mission's original replay_baseline.py is preserved unchanged and refuses to overwrite its already occupied coordinator_baseline_001 directory. The commands above use a new destination. The finite comparison should exceed1.2e-8 and both point tails should be positive, with complete finite and truncation objects matching those saved in coordinator_baseline_001. These commands execute underlying Bessel/integral calculations, not stored-endpoint validation.

## Integrity and scope

MANIFEST.sha256.json lists every successor payload file other than itself. verify_integrity.py checks those bytes, and the external ZIP sidecar binds the archive. FINAL_INTEGRITY_RESULTS.json is external to avoid self-reference and records archive/PDF hashes, payload checks and CRC. Hashes identify bytes; they do not establish mathematical correctness or authorship.

The original adjacent mission's overwritten first D output/log is not recovered. A new inline diagnostic and B's first finite check have incomplete pre-execution provenance, clearly disclosed in AGENT_RECORD.md. All official sources and actual results are preserved; fresh prehashed coordinator replays exist. No missing original execution bytes are represented as restored.

The new cone has no Arb/FLINT premise; the preserved finite-height coverage does. All-height second-tail positivity, the complete transform sign, an initial global fixed strip and RH remain unresolved. No historical novelty, independent human expert review, formal verification or causal Protocol A benefit is claimed.
