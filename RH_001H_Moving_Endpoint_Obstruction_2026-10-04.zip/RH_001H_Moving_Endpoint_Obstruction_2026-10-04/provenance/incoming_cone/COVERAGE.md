# Proved and unresolved regions

Write tau=|t| and L(Z)=log(Z/(2pi))/2. All radial endpoints in this record are nonnegative. Boundaries shown with <= or >= are included.

## New analytic result

For every tau>=34, g_t(r)>0 for r>=L(5tau/4), and V_2,t(R)>0 for R>=L(5tau/4). The original proposed cone L(2tau), and the intermediate coefficient 3/2, are contained in this proved region. No optimal cone or smallest threshold is claimed.

The new result has no numerical interval premise. It is the complete proof in PROOF.md P2-P5. The exact checker guards finite constants only.

## Preserved inherited coverage

| Absolute height | Kernel and tail threshold | Status |
|---|---|---|
| tau<=32 | r,R>=L(33) | Inherited from the all-endpoints t=32 mission; no new full replay |
| tau<=33 | r,R>=L(34) | Inherited from the [31,33] band mission |
| tau<=34 | r,R>=L(35) | Inherited analytic lemma; T=34,Z=35 finite comparison freshly replayed |
| tau<=64 | r,R>=L(65) | Inherited theorem; no new full replay |
| 31<=tau<=34 | V_2,t(R)>0 for every R>=0 | Inherited complete finite-height certificates; only the relevant t=34 boundary seed replayed here |

The last row is an all-endpoint V2 statement. It does not assert g_t(r)>0 throughout the same compact region. Each inherited numerical theorem retains its disclosed Arb/FLINT trust model.

## Best simple V2 union from these theorems

| Absolute height | Sufficient endpoint range for V2>0 |
|---|---|
| 0<=tau<31 | R>=L(33) |
| 31<=tau<=34 | R>=0 |
| 34<tau<=52 | R>=L(5tau/4) |
| 52<tau<=64 | R>=L(65) |
| tau>64 | R>=L(5tau/4) |

At tau=52 the two cutoffs are exactly equal, since 5*52/4=65. For 52<tau<=64 the old L(65) cutoff is better, and is retained. This table summarizes continuous-region theorems; it does not discard any inherited isolated point certificates preserved in the predecessor archives.

For g itself, the best listed cutoff is L(33) for tau<=32, L(34) for 32<tau<=33, L(35) for 33<tau<=34, L(5tau/4) for 34<tau<=52, L(65) for 52<tau<=64, and L(5tau/4) for tau>64.

## Remaining task

For tau>34, decide the second-tail sign throughout 0<=R<R_best(tau), where R_best is the cutoff in the table. The new unbounded-height obligation is particularly clear at tau>64:

\[
0\le R<\tfrac12\log\frac{5\tau}{8\pi}.
\]

This is compact in R at each fixed height, but its size grows logarithmically with height. One specific next task is to construct uniform height-dependent boundary models at b(tau)=L(5tau/4) and prove a lower bound under backward transport to R=0, or certify a negative V2 candidate. A positive boundary value alone gives no such transport theorem. The phase-sensitive compact contribution and V2(0) remain uncontrolled at general large height.

Regions below L(33) at tau<31 also receive no new sign theorem in this mission. All-height second-tail positivity, positivity of the aggregate transform, an initial global fixed strip and descent to RH remain separate. Tail positivity supplies a rigorously controlled outer boundary, not any of those global conclusions.
